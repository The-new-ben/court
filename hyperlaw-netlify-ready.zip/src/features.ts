/*
 * This module defines the list of features available in the HyperLaw platform.
 * Each feature contains a unique id, a short title and a concise description.
 * These features are inspired by contemporary trends in legal‑tech, artificial
 * intelligence, user experience and gamification. While some of them are
 * placeholders for future development, they outline the intended scope of the
 * platform.
 */

export interface Feature {
  id: number;
  title: string;
  description: string;
}

export const features: Feature[] = [
  { id: 1, title: 'AI‑powered contract review', description: 'Automatically analyze contracts to identify key clauses and potential risks.' },
  { id: 2, title: 'Automated document drafting', description: 'Generate standard legal documents from templates with dynamic fields.' },
  { id: 3, title: 'Predictive analytics', description: 'Use historical data to forecast case outcomes and inform strategy.' },
  { id: 4, title: 'Document classification', description: 'Organize large volumes of legal documents using NLP techniques.' },
  { id: 5, title: 'AI‑assisted legal research', description: 'Search case law and statutes with natural language queries.' },
  { id: 6, title: 'Digital client portal', description: 'Provide clients with real‑time access to their case status and documents.' },
  { id: 7, title: 'Case management system', description: 'Centralize document storage, billing, and task tracking.' },
  { id: 8, title: 'Time and billing tracking', description: 'Track billable hours and expenses seamlessly.' },
  { id: 9, title: 'Collaboration tools', description: 'Collaborate with colleagues through shared notes and tasks.' },
  { id: 10, title: 'Calendar integration', description: 'Sync hearings and deadlines with your calendar app.' },
  { id: 11, title: 'End‑to‑end encryption', description: 'Protect sensitive data in transit and at rest.' },
  { id: 12, title: 'Multi‑factor authentication', description: 'Add an extra layer of security to user logins.' },
  { id: 13, title: 'Role‑based access control', description: 'Ensure users only access information pertinent to their role.' },
  { id: 14, title: 'Audit trails', description: 'Maintain a chain‑of‑custody log for all actions and evidence.' },
  { id: 15, title: 'Privacy compliance', description: 'Built‑in support for GDPR, CCPA and other privacy regulations.' },
  { id: 16, title: 'Virtual courtrooms', description: 'Conduct hearings remotely in immersive virtual environments.' },
  { id: 17, title: 'Mock trial simulations', description: 'Rehearse arguments and evidence presentation using VR.' },
  { id: 18, title: '3‑D evidence visualization', description: 'Display crime scenes and evidence in three dimensions.' },
  { id: 19, title: 'Augmented reality review', description: 'Overlay annotations on physical documents or exhibits.' },
  { id: 20, title: 'Remote collaboration', description: 'Work with clients and colleagues from anywhere via immersive tech.' },
  { id: 21, title: 'E‑discovery automation', description: 'Automatically identify, collect and analyze electronic evidence.' },
  { id: 22, title: 'Legal analytics dashboard', description: 'Visualize data patterns and trends across cases.' },
  { id: 23, title: 'Knowledge graphs', description: 'Map relationships between legal concepts, cases and statutes.' },
  { id: 24, title: 'Network graph analysis', description: 'Analyze relationships among litigants, lawyers and judges.' },
  { id: 25, title: 'Risk scoring and forecasting', description: 'Assess risk and predict costs for potential cases.' },
  { id: 26, title: 'Cloud‑hosted platform', description: 'Access your workspace from anywhere with high availability.' },
  { id: 27, title: 'Client self‑service portal', description: 'Clients can upload documents, pay invoices and send messages.' },
  { id: 28, title: 'Online payments', description: 'Integrated billing and online payment processing.' },
  { id: 29, title: 'Document automation', description: 'Create custom forms and generate documents dynamically.' },
  { id: 30, title: 'Online dispute resolution', description: 'Facilitate mediation and arbitration through digital tools.' },
  { id: 31, title: 'AI chatbot', description: 'Automate client intake and answer frequently asked questions.' },
  { id: 32, title: 'Conversational agent', description: 'Chat with an AI assistant connected to legal knowledge bases.' },
  { id: 33, title: 'Speech‑to‑text dictation', description: 'Transcribe spoken words into searchable text.' },
  { id: 34, title: 'Multilingual translation', description: 'Translate documents and conversations into multiple languages.' },
  { id: 35, title: 'Explainable AI interface', description: 'Provide insights into how AI reaches its recommendations.' },
  { id: 36, title: 'Points and badges', description: 'Reward users for completing tasks and contributions.' },
  { id: 37, title: 'Leaderboards', description: 'Rank users based on their activity and achievements.' },
  { id: 38, title: 'Challenges and milestones', description: 'Encourage participation through quests and objectives.' },
  { id: 39, title: 'Reward systems', description: 'Earn virtual currency to redeem benefits or donations.' },
  { id: 40, title: 'Educational mini‑games', description: 'Learn legal principles through interactive games.' },
  { id: 41, title: 'Secure video upload', description: 'Upload and store video evidence with tamper detection.' },
  { id: 42, title: 'Integrity verification', description: 'Validate the authenticity of digital evidence.' },
  { id: 43, title: 'AI‑powered redaction', description: 'Automatically blur faces and mute sensitive audio.' },
  { id: 44, title: 'Evidence repository', description: 'Centralized storage for all types of digital evidence.' },
  { id: 45, title: 'Chain‑of‑custody logs', description: 'Track how evidence is handled over time.' },
  { id: 46, title: 'Community forum', description: 'Engage with peers in a moderated discussion space.' },
  { id: 47, title: 'Integration API', description: 'Connect with third‑party services such as research databases.' },
  { id: 48, title: 'Microservices architecture', description: 'Scalable backend built from independent services.' },
  { id: 49, title: 'Responsive PWA design', description: 'Works offline and adapts to any screen size.' },
  { id: 50, title: 'Accessibility and i18n', description: 'Support right‑to‑left languages and WCAG standards.' },
];