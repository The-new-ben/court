import React from 'react';

const Gamification: React.FC = () => (
  <div className="bg-white rounded-xl shadow p-4">
    <h2 className="text-xl font-semibold mb-2 text-gray-900">Gamification</h2>
    <p className="text-sm text-gray-600">
      Earn points, badges, and climb leaderboards for engaging with the platform. (Coming soon)
    </p>
  </div>
);

export default Gamification;