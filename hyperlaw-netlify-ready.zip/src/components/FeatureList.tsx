import React from 'react';
import { features } from '../features';

const FeatureList: React.FC = () => (
  <div id="features" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
    {features.map((feature) => (
      <div
        key={feature.id}
        className="bg-white rounded-xl shadow p-4 hover:shadow-md transition"
      >
        <h3 className="text-lg font-semibold mb-2 text-gray-900">
          {feature.title}
        </h3>
        <p className="text-sm text-gray-600">
          {feature.description}
        </p>
      </div>
    ))}
  </div>
);

export default FeatureList;