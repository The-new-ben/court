import React, { useState } from 'react';

const UploadEvidence: React.FC = () => {
  const [fileName, setFileName] = useState<string | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileName(file.name);
      // In a real implementation, the file would be uploaded to a backend.
    }
  };

  return (
    <div id="upload" className="bg-white rounded-xl shadow p-4">
      <h2 className="text-xl font-semibold mb-2 text-gray-900">Upload Video Evidence</h2>
      <p className="text-sm text-gray-600 mb-4">
        Select a video file to upload (for demonstration only).
      </p>
      <input
        type="file"
        accept="video/*"
        onChange={handleChange}
        className="border rounded p-2"
      />
      {fileName && (
        <p className="mt-2 text-sm text-green-600">Selected file: {fileName}</p>
      )}
    </div>
  );
};

export default UploadEvidence;