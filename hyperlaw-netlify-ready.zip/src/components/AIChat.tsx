import React from 'react';

const AIChat: React.FC = () => (
  <div className="bg-white rounded-xl shadow p-4">
    <h2 className="text-xl font-semibold mb-2 text-gray-900">AI Legal Assistant</h2>
    <p className="text-sm text-gray-600">
      Interact with our AI‑powered assistant for quick insights. Note: AI responses are for informational purposes and require professional legal review.
    </p>
  </div>
);

export default AIChat;