import React from 'react';

const Community: React.FC = () => (
  <div id="community" className="bg-white rounded-xl shadow p-4">
    <h2 className="text-xl font-semibold mb-2 text-gray-900">Community Forum</h2>
    <p className="text-sm text-gray-600">
      Connect with legal professionals, share knowledge, and engage in discussions. (Coming soon)
    </p>
  </div>
);

export default Community;