import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-white shadow">
      <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <span className="text-xl font-bold text-blue-600">HyperLaw</span>
        </div>
        <nav className="space-x-4 hidden md:block">
          <a href="#features" className="text-gray-700 hover:text-blue-600">Features</a>
          <a href="#community" className="text-gray-700 hover:text-blue-600">Community</a>
          <a href="#upload" className="text-gray-700 hover:text-blue-600">Upload</a>
        </nav>
      </div>
    </header>
  );
};

export default Header;