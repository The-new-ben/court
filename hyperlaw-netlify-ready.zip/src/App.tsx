import React from 'react';
import Header from './components/Header';
import FeatureList from './components/FeatureList';
import UploadEvidence from './components/UploadEvidence';
import Community from './components/Community';
import Gamification from './components/Gamification';
import AIChat from './components/AIChat';

const App: React.FC = () => {
  const year = new Date().getFullYear();
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <main className="flex-1">
        <section className="px-4 py-8 text-center">
          <h1 className="text-4xl font-bold mb-4 text-gray-900">HyperLaw Platform</h1>
          <p className="text-lg text-gray-600 mb-8">
            Next‑generation legal‑tech platform empowered by AI and modern UX.
          </p>
          <FeatureList />
        </section>
        <section className="px-4 py-8 space-y-8">
          <UploadEvidence />
          <Community />
          <Gamification />
          <AIChat />
        </section>
      </main>
      <footer className="bg-gray-800 text-white text-center py-4">
        &copy; {year} HyperLaw. All rights reserved.
      </footer>
    </div>
  );
};

export default App;